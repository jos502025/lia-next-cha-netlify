# LÍA Chat — Next.js (App Router) + Netlify

Minimal, técnico y listo para producción.

## 1) Instalación local
```bash
npm i
cp .env.example .env.local
# coloca tu OPENAI_API_KEY y verifica NEXT_PUBLIC_LIA_WHATSAPP_NUMBER=5213318761197
npm run dev
```

## 2) Estructura
```
app/
  api/chat/route.ts      # endpoint Responses API (stream opcional)
  layout.tsx
  page.tsx
components/
  ChatBox.tsx            # UI con switch modelo y streaming
  WhatsAppFloat.tsx      # botón WA flotante (número público)
globals.css
next.config.js
netlify.toml
tsconfig.json
.env.example
```

## 3) Variables de entorno (Netlify)
- `OPENAI_API_KEY` = `sk-...`
- `NEXT_PUBLIC_LIA_WHATSAPP_NUMBER` = `5213318761197`

## 4) Netlify
- Build: `npm run build`
- Node: `18`
- Plugin: `@netlify/plugin-nextjs`

## 5) Notas
- Modelos: `gpt-5-mini` (default) o `gpt-5` (seleccionable en UI).
- El endpoint usa `client.responses.stream(...)` si `stream: true`.
```

