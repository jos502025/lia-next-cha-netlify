'use client';

import { useEffect, useRef, useState } from 'react';
type Message = { role: 'user' | 'assistant'; content: string };

export default function ChatBox() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Hola, soy tu Navegante LÍA. ¿Sobre qué te ayudo hoy? (PSI, TIC, diagnóstico, inversión, plusvalía...)' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [model, setModel] = useState<'gpt-5-mini' | 'gpt-5'>('gpt-5-mini');
  const [useStream, setUseStream] = useState(true);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [messages]);

  async function sendMessage() {
    if (!input.trim() || loading) return;
    const userText = input.trim();
    setInput('');
    setLoading(true);
    setMessages(prev => [...prev, { role: 'user', content: userText }]);

    if (useStream) {
      const placeholderIndex = messages.length + 1;
      setMessages(prev => [...prev, { role: 'assistant', content: '' }]);
      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: userText, model, stream: true })
        });
        if (!res.body) throw new Error('No stream');
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let acc = '';
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          acc += decoder.decode(value, { stream: true });
          setMessages(prev => { const c = [...prev]; c[placeholderIndex] = { role: 'assistant', content: acc }; return c; });
        }
      } catch {
        setMessages(prev => [...prev, { role: 'assistant', content: 'Error de red. Intenta nuevamente.' }]);
      } finally { setLoading(false); }
    } else {
      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: userText, model, stream: false })
        });
        const data = await res.json();
        setMessages(prev => [...prev, { role: 'assistant', content: data.reply || 'Gracias, ¿puedes darme más contexto?' }]);
      } catch {
        setMessages(prev => [...prev, { role: 'assistant', content: 'Error de red. Intenta nuevamente.' }]);
      } finally { setLoading(false); }
    }
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') sendMessage();
  }

  return (
    <div>
      <div style={{ display:'flex', gap:12, alignItems:'center', padding:'10px 12px', borderBottom:'1px solid #E5E5E5' }}>
        <label style={{ fontSize:13 }}>
          Modelo:&nbsp;
          <select value={model} onChange={e => setModel(e.target.value as any)} style={{ padding:6, borderRadius:6, border:'1px solid #d1d5db' }}>
            <option value="gpt-5-mini">mini (rápido/barato)</option>
            <option value="gpt-5">pro (momentos de verdad)</option>
          </select>
        </label>
        <label style={{ fontSize:13, display:'flex', gap:6, alignItems:'center' }}>
          <input type="checkbox" checked={useStream} onChange={e => setUseStream(e.target.checked)} />
          Streaming
        </label>
      </div>

      <div className="chat-body" ref={listRef}>
        {messages.map((m, i) => (<div key={i} className={`msg ${m.role === 'assistant' ? 'bot' : 'user'}`}>{m.content}</div>))}
      </div>

      <div className="chat-form">
        <input className="input" placeholder={loading ? "Enviando..." : "Escribe aquí..."} value={input} onChange={(e)=>setInput(e.target.value)} onKeyDown={onKeyDown} disabled={loading}/>
        <button className="btn-lia" onClick={sendMessage} disabled={loading}>{loading ? '...' : 'Enviar'}</button>
      </div>
    </div>
  );
}
