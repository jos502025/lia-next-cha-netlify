'use client';
import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';

export default function WhatsAppFloat() {
  const pathname = usePathname();
  const [href, setHref] = useState('#');
  const [tooltip, setTooltip] = useState('Hablar con un Navegante LÍA');

  useEffect(() => {
    const number = process.env.NEXT_PUBLIC_LIA_WHATSAPP_NUMBER || '5213318761197';
    const base = `https://wa.me/${number}?text=`;
    let message = 'Hola, quiero más información sobre LÍA.';
    let tip = 'Hablar con un Navegante LÍA';
    if (pathname?.includes('nivel-psi')) { message = 'Hola, estoy interesado en el Nivel PSI de LÍA.'; tip = 'Hablar sobre Nivel PSI'; }
    else if (pathname?.includes('tic')) { message = 'Hola, me interesa hacer el Test Inteligente de Claridad (TIC).'; tip = 'Agendar Test de Claridad (TIC)'; }
    else if (pathname?.includes('diagnostico')) { message = 'Hola, quiero agendar un diagnóstico estratégico con LÍA.'; tip = 'Solicitar Diagnóstico Estratégico'; }
    else if (pathname?.includes('expansion')) { message = 'Hola, quiero conocer más sobre el acompañamiento en expansión.'; tip = 'Explorar Expansión con LÍA'; }
    setHref(base + encodeURIComponent(message));
    setTooltip(tip);
  }, [pathname]);

  return (
    <a id="lia-whatsapp-btn" className="btn-lia-whatsapp-float" href={href} data-tooltip={tooltip} target="_blank" aria-label="WhatsApp LÍA">
      <span style={{fontSize:0}}>WhatsApp</span>
      <svg aria-hidden="true" width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M20.52 3.48A11.86 11.86 0 0 0 12.06 0C5.46 0 .1 5.35.1 11.95c0 2.09.55 4.12 1.6 5.92L0 24l6.29-1.64A11.86 11.86 0 0 0 12.06 24c6.6 0 11.95-5.36 11.95-11.95 0-3.19-1.24-6.19-3.49-8.57Z"/></svg>
    </a>
  );
}
