import ChatBox from "@/components/ChatBox";
import WhatsAppFloat from "@/components/WhatsAppFloat";

export default function Home() {
  return (
    <main className="container">
      <header className="header">
        <div className="brand">LÍA Consultoría</div>
        <div className="badge">MVP escalable</div>
      </header>

      <section className="hero">
        <h1>Chat consultivo — Tu Navegante LÍA</h1>
        <p>Resuelve dudas en 3 minutos, sin compromiso. Si lo necesitas, te conectamos con un Navegante por WhatsApp.</p>

        <div className="chat-wrap" style={{marginTop: 16}}>
          <div className="chat-header">Asistente LÍA</div>
          <ChatBox />
        </div>
      </section>

      <WhatsAppFloat />
    </main>
  );
}
