import { NextRequest } from "next/server";
import OpenAI from "openai";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const { message, model = "gpt-5-mini", stream = true } = await req.json();

  if (!process.env.OPENAI_API_KEY) {
    return new Response(JSON.stringify({ error: "Falta OPENAI_API_KEY" }), { status: 500 });
  }
  if (!message || typeof message !== "string") {
    return new Response(JSON.stringify({ error: "Mensaje inválido" }), { status: 400 });
  }

  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  const system = `Eres un asesor inmobiliario de LÍA Consultoría: claro, empático, estratégico y orientado a resultados.
Usa el tono LÍA (confianza, claridad, ROI, plusvalía). Haz preguntas abiertas y evita vender por vender.`;

  try {
    if (stream) {
      const s = await client.responses.stream({
        model,
        input: [
          { role: "system", content: system },
          { role: "user", content: message.slice(0, 2000) }
        ],
        max_output_tokens: 500
      });
      const rs = s.toReadableStream();
      return new Response(rs, {
        headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-cache" }
      });
    }

    const r = await client.responses.create({
      model,
      input: [
        { role: "system", content: system },
        { role: "user", content: message.slice(0, 2000) }
      ],
      max_output_tokens: 500
    });
    return new Response(JSON.stringify({ reply: r.output_text ?? "" }), { headers: { "Content-Type": "application/json" }});
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: "Error interno" }), { status: 500 });
  }
}
